package application;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;


public class FXMLDocumentController implements Initializable {

	@FXML
	private Label label;

	@FXML
	TextField flavorTF,sizeTF;

	@FXML
	Button orderFlavorBtn,orderSizeBtn;

	@FXML
	TextArea orderTextArea;

	@Override
	public void initialize(URL url, ResourceBundle rb) {

	}

	//FXML action events for Flavor portion of program
	@FXML
	public void orderFlavor(ActionEvent ev)
	{
	Flavor flavor=new Flavor();
	String flavorName=flavorTF.getText();
	flavor.setFlavorName(flavorName);
	ordersPlaced(flavor);
	System.out.print("orderFlavor");

	}
	//FXML action events for Size portion of program
	@FXML
	public void orderSize(ActionEvent ev)
	{
	Size size=new Size();
	String sizeName=sizeTF.getText();
	size.setSizeName(sizeName);
	ordersPlaced(size);
	System.out.print("orderSize");
	}

	//Orders placed initiation
	public void ordersPlaced(Object item)
	{
	String items="";

	if(item instanceof Flavor)
	{
	items=((Flavor) item).getFlavorName();
	}
	else if(item instanceof Size)
	{
	items=((Size) item).getSizeName();

	}

	orderTextArea.setText(orderTextArea.getText()+"\n"+"Your order of "+ items +" is placed."+ "\n");
	}
}

