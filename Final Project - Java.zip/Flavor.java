package application;

public class Flavor extends Price {
		
	private String flavorName;
		private float price;
		//getter for flavor (name)
		public String getFlavorName() {
		return flavorName;
		}
		//setter for flavor
		public void setFlavorName(String flavorName) {
		this.flavorName = flavorName;
		}
		//get price for flavor
		public float getPrice() {
		return price;
		}
		//set price for flavor
		public void setPrice(float price) {
		this.price = price;
		}
}

