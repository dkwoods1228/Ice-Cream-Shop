package application;

public class Size extends Price {
	private String sizeName;
	private float price;
	//size getter
	public String getSizeName() {
	return sizeName;
	}
	//size setter
	public void setSizeName(String sizeName) {
	this.sizeName = sizeName;
	}
	//get and return price
	public float getPrice() {
	return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}
	
}
