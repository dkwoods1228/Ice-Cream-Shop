package application;

public class Price {
	public class Size extends Price{
		//getter & return size name
		private String sizeName;
		public String getSizeName() {
		return sizeName;
		}
		//size setter
		public void setSizeName(String sizeName) {
		this.sizeName = sizeName;
		}
		//get price for size
		public float getPrice() {
		return getPrice();
		}
		//set price for size
		public void setPrice(float price) {
		}

		}
	}
